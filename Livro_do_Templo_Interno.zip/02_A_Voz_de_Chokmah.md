# A Voz de Chokmah

O Sopro Criador. O desejo que impulsiona o Verbo. O ímpeto de mover, dançar, agir.