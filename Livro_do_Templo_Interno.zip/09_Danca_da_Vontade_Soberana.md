# Dança da Vontade Soberana

Confiança e Raiva como forças irmãs.