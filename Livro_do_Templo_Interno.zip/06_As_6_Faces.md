# As 6 Faces

Amor, Medo, Confiança, Raiva, Alegria, Tristeza.