# Fechamento do Cubo

A Obra como Altar. O Corpo como Templo. O Verbo como Silêncio.