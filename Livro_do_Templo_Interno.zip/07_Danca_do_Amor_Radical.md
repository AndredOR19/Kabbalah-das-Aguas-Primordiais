# Dança do Amor Radical

Abertura do Coração. Entrega com discernimento.