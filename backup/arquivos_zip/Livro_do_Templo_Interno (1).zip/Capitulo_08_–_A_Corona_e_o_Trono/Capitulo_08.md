# Capitulo 08 – A Corona e o Trono

> *Texto inicial do capítulo 8.*

## Seções principais

- Introdução
- Estrutura vibracional
- Correspondências cabalísticas
- Prática ritual
