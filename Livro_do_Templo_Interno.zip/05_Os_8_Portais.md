# Os 8 Portais

Quatro superiores, quatro inferiores. Estaçōes do espírito.