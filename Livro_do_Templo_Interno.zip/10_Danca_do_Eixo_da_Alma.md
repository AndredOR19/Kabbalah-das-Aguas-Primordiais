# Dança do Eixo da Alma

Alegria e Tristeza como margens do mesmo rio.