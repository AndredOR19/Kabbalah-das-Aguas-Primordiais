# Dança do Medo que Cura

Escuta do Corpo. Presença que acolhe.