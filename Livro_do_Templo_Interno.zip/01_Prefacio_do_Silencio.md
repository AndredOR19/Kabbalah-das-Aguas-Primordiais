# Prefácio do Silêncio

No princípio, não era a palavra. Era o impulso de dizê-la.