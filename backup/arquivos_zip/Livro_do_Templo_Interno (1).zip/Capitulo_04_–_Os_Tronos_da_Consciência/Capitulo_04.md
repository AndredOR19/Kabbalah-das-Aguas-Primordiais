# Capitulo 04 – Os Tronos da Consciência

> *Texto inicial do capítulo 4.*

## Seções principais

- Introdução
- Estrutura vibracional
- Correspondências cabalísticas
- Prática ritual
