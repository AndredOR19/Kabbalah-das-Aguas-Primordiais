# Os 12 Rios da Alma

Cartografia interna dos meridianos e seus símbolos.