# O Silêncio como Forma Final

Não há verbo. Só a Presença. Só o Ser.