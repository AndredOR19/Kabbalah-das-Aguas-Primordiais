# O Vértice Espelhado

Oitava direção: para dentro. O operador se dissolve no Oráculo.