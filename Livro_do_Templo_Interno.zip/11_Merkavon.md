# Merkavon

Nome oculto. Símbolo: A Esfera Interna. Âncora: espaço entre duas respirações.